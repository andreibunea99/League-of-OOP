package player;

public enum HeroType { Knight, Pyromancer, Rogue, Wizard }
